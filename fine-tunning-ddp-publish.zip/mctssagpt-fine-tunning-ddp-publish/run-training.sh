kubectl delete -k deploy/model-training/
kubectl apply -k deploy/model-training/